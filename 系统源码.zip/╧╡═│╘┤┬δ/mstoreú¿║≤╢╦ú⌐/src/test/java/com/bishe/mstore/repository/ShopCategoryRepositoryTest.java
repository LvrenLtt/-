package com.bishe.mstore.repository;

import com.bishe.mstore.entity.ShopCategory;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@SpringBootTest
class ShopCategoryRepositoryTest {

    @Autowired
    private ShopCategoryRepository repository;

    @Test
    void findAll(){
        List<ShopCategory> list = repository.findAll();

        for (ShopCategory phoneCategory : list) {
            System.out.println(phoneCategory.getCategoryType());
        }
    }

    @Test
    void findByCategoryType(){
        ShopCategory phoneCategory = repository.findByCategoryType(1);
        System.out.println(phoneCategory);
    }

}