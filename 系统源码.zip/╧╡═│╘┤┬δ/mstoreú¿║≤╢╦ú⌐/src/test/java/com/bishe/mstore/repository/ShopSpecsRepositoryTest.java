package com.bishe.mstore.repository;

import com.bishe.mstore.entity.ShopSpecs;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@SpringBootTest
class ShopSpecsRepositoryTest {

    @Autowired
    private ShopSpecsRepository repository;

    @Test
    void findAll(){
        List<ShopSpecs> list = repository.findAll();
        for (ShopSpecs shopSpecs : list) {
            System.out.println(shopSpecs);
        }
    }

    @Test
    void findAllByShopId(){
        List<ShopSpecs> list = repository.findAll();
        for (ShopSpecs shopSpecs : list) {
            System.out.println(shopSpecs);
        }
    }
    @Test
    void findAllBySpecsId(){
        List<ShopSpecs> list = repository.findAllBySpecsId(1);
        for (ShopSpecs shopSpecs : list) {
            System.out.println(shopSpecs);
        }
    }

}