package com.bishe.mstore.repository;

import com.bishe.mstore.entity.Cart;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
@SpringBootTest
class CartRepositoryTest {
@Autowired
        private CartRepository repository;
        @Test
    void  find(){
            System.out.println(repository.findAll());
        }
       int  userId=1;
        @Test
        void findAllByUserId(){
            List<Cart> list = repository.findAllByUserId("1");
            for (Cart shopInfo : list) {
                System.out.println(shopInfo);
            }
        }
        @Test
        void delete(){
            repository.deleteById(19);
        }
}