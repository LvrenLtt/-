package com.bishe.mstore.repository;

import com.bishe.mstore.entity.User;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
@SpringBootTest
class UserRepositoryTest {
@Autowired
    private UserRepository repository;
    @Test
    void find(){
    List<User> list = repository.findAll();
        for (User shopSpecs : list) {
            System.out.println(shopSpecs);
        }
    }
}