package com.bishe.mstore.repository;

import com.bishe.mstore.entity.ShopInfo;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@SpringBootTest
class ShopInfoRepositoryTest {

    @Autowired
    private ShopInfoRepository repository;

    @Test
    void findAll(){
        List<ShopInfo> list = repository.findAll();
        for (ShopInfo shopInfo : list) {
            System.out.println(shopInfo);
        }
    }

    @Test
    void findAllByCategoryType(){
        List<ShopInfo> list = repository.findAllByCategoryType(1);
        for (ShopInfo shopInfo : list) {
            System.out.println(shopInfo);
        }
    }
    @Test
    void save(){

    }

}