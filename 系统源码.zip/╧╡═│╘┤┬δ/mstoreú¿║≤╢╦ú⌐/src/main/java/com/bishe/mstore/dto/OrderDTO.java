package com.bishe.mstore.dto;

import lombok.Data;

@Data
public class OrderDTO {
    private String orderId;
    private String buyerName;
    private String buyerPhone;
    private String buyerAddress;
    private Integer specsId;
    private Integer shopQuantity;
    private Integer userId;
}
