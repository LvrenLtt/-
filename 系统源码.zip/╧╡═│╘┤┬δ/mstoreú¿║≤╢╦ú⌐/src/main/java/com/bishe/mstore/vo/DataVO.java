package com.bishe.mstore.vo;

import lombok.Data;

import java.util.List;

@Data
public class DataVO {
    private List<ShopCategoryVO> categories;
    private List<ShopInfoVO> shops;
}
