package com.bishe.mstore.vo;

import lombok.Data;

import java.math.BigDecimal;
@Data
public class CartVO {
    private Integer cartId;
    private Integer shopId;
    private String userId;
    private String shopName;
    private Integer shopQuantity;
    private String shopIcon;
    private String specsId;
}
