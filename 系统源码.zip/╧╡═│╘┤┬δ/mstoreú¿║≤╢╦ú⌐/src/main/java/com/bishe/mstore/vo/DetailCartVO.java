package com.bishe.mstore.vo;

import lombok.Data;

@Data
public class DetailCartVO {
    private String orderId;
    private String buyerName;
    private String buyerPhone;
    private String buyerAddress;
    private Integer userId;
}
