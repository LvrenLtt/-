package com.bishe.mstore.repository;

import com.bishe.mstore.entity.ShopCategory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ShopCategoryRepository extends JpaRepository<ShopCategory,Integer> {
    public ShopCategory findByCategoryType(Integer categoryType);

   public ShopCategory findAllByCategoryType(Integer categoryType);
}
