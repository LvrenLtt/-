package com.bishe.mstore.repository;

import com.bishe.mstore.entity.Admir;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AdmirRespository extends JpaRepository<Admir,Integer> {
}
