package com.bishe.mstore.vo;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class CartOrderVO {
    private String buyerName;
    private String buyerPhone;
    private String buyerAddress;
    private BigDecimal orderAmount;
    private Integer userId;
}
