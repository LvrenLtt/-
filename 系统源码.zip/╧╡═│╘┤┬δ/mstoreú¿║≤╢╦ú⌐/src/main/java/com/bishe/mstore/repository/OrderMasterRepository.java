package com.bishe.mstore.repository;

import com.bishe.mstore.entity.OrderMaster;

import com.bishe.mstore.vo.OrderVO;
import com.bishe.mstore.vo.ResultVO;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface OrderMasterRepository extends JpaRepository<OrderMaster,String> {


   public List<OrderMaster> findOrderByPayStatus(Integer payStatus);


}
