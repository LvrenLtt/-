package com.bishe.mstore.repository;

import com.bishe.mstore.entity.ShopInfo;
import com.bishe.mstore.entity.ShopSpecs;
import com.bishe.mstore.vo.ShopInfoVO;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ShopInfoRepository extends JpaRepository<ShopInfo,Integer> {
    public List<ShopInfo> findAllByCategoryType(Integer categoryType);
    public List<ShopInfo> findAllByShopNameLike(String shopName);
    List<ShopInfo> findAllByShopId(Integer shopId);
    public ShopInfo findAllByShopName(String shopName);

    List<ShopInfo> findShopByShopStatus(Integer shopStatus);
}
