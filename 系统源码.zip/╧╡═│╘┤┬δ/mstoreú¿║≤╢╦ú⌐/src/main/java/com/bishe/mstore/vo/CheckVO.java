package com.bishe.mstore.vo;

import lombok.Data;

@Data
public class CheckVO {
    private Integer shopId;
    private String shopName;
    private String specsName;
    private Integer shopQuantity;
    private String shopIcon;

}
