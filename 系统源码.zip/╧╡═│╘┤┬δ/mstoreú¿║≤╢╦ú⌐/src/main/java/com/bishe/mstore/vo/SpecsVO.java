package com.bishe.mstore.vo;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class SpecsVO {
    private String shopName;
    private String specsName;
    private Integer specsStock;
    private BigDecimal specsPrice;
    private String specsIcon;
    private String specsPreview;

}
