package com.bishe.mstore.controller;

import com.bishe.mstore.entity.ShopCategory;
import com.bishe.mstore.entity.ShopInfo;
import com.bishe.mstore.entity.ShopSpecs;
import com.bishe.mstore.repository.ShopCategoryRepository;
import com.bishe.mstore.repository.ShopInfoRepository;
import com.bishe.mstore.repository.ShopSpecsRepository;
import com.bishe.mstore.service.ShopService;
import com.bishe.mstore.util.ResultVOUtil;
import com.bishe.mstore.vo.ResultVO;
import com.bishe.mstore.vo.ShopVO;
import com.bishe.mstore.vo.SpecsVO;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/shop")
public class ShopHandler {

    @Autowired
    private ShopService shopService;
    @Autowired
    private ShopInfoRepository shopInfoRepository;
    @Autowired
    private ShopSpecsRepository shopSpecsRepository;


    @GetMapping("/index")
    public ResultVO index(){
        return ResultVOUtil.success(shopService.findDataVO());
    }

    @GetMapping("/findByCategoryType/{categoryType}")
    public ResultVO findByCategoryType(
            @PathVariable("categoryType") Integer categoryType){
        return ResultVOUtil.success(shopService.findShopInfoVOByCategoryType(categoryType));
    }

    @GetMapping("/findSpecsByShopId/{shopId}")
    public ResultVO findSpecsByShopId(
            @PathVariable("shopId") Integer shopId){
        return ResultVOUtil.success(shopService.findSpecsByShopId(shopId));
    }
    @GetMapping("/findByShopName/{shopName}")
    public ResultVO findSpecsByShopName(
            @PathVariable("shopName") String shopName){
        return ResultVOUtil.success(shopService.findShopInfoVOByShopNameLike(shopName));
    }
    @PostMapping("/deleteByShopId/{shopId}")
    public int deleteByShopId(
            @PathVariable("shopId") Integer shopId){
        shopInfoRepository.deleteById(shopId);
        shopSpecsRepository.deleteById(shopId);
        return 1;
    }

    @PostMapping("/save")
    public int save(@RequestBody ShopVO shopInfo){
        List<ShopInfo> list=shopInfoRepository.findAll();
        for (ShopInfo shopInfo2:list){
            if (shopInfo2.getShopName().equals(shopInfo.getShopName()))
            {
                BeanUtils.copyProperties(shopInfo,shopInfo2);
                shopInfo.setShopStatus(0);
                shopInfoRepository.save(shopInfo2);
                return 1;
            }
        }
       ShopInfo shopInfo1 = new ShopInfo();
        shopInfo.setShopStatus(0);
            BeanUtils.copyProperties(shopInfo,shopInfo1);

            shopInfoRepository.save(shopInfo1);

        return 1;
    }
    @PostMapping("/saveSpecs")
    public int saveSpecs(@RequestBody SpecsVO specsVO){
        ShopInfo shopInfo=shopInfoRepository.findAllByShopName(specsVO.getShopName());
        List<ShopSpecs> shopSpecs=shopSpecsRepository.findAll();
        for(ShopSpecs shopSpecs2:shopSpecs){
            if (shopSpecs2.getSpecsName().equals(specsVO.getSpecsName())){
                BeanUtils.copyProperties(specsVO,shopSpecs2);
                shopSpecs2.setShopId(shopInfo.getShopId());
                shopSpecsRepository.save(shopSpecs2);
                return 1;
            }
        }
        ShopSpecs shopSpecs1 = new ShopSpecs();
        BeanUtils.copyProperties(specsVO,shopSpecs1);
        shopSpecs1.setShopId(shopInfo.getShopId());
        shopSpecsRepository.save(shopSpecs1);
        return 1;
    }
}
