package com.bishe.mstore.controller;

import com.bishe.mstore.entity.User;
import com.bishe.mstore.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.DigestUtils;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/login")
public class UserHandler {
    @Autowired
    private UserRepository repository;

    @PostMapping("/logining")
    public int check(@RequestBody User user){
        int resp=0;
        String md5Password = DigestUtils.md5DigestAsHex(user.getPassword().getBytes());
        user.setPassword(md5Password);
        List<User> list = repository.findAll();
        for (User user1 : list) {
            if (user.getUsername().equals(user1.getUsername())&&user.getPassword().equals(user1.getPassword())) {
                   resp= user1.getUserid();
            }
        }
        return resp;
    }




   @PostMapping("/reg")
    public int save( @RequestBody User user){
      int resp=0;
       String md5Password = DigestUtils.md5DigestAsHex(user.getPassword().getBytes());
       user.setPassword(md5Password);
//       System.out.println(user.getUsername());
       List<User> list = repository.findAll();
       for (User user1 : list) {
           if(user.getUsername().equals(user1.getUsername())){
               resp=1;
           }
       }

        if (resp==1){
            return 1 ;
        }
        else{
         repository.save(user);
           return 2;
        }
    }
    @PostMapping("/changeByUserName")
    public int updatePassword(@RequestBody User user) {
        int resp = 0;
        String md5Password = DigestUtils.md5DigestAsHex(user.getPassword().getBytes());
        user.setPassword(md5Password);
//       System.out.println(user.getUsername());
        List<User> list = repository.findAll();
        for (User user1 : list) {
            if (user.getUsername().equals(user1.getUsername())) {
                user1.setPassword(user.getPassword());
                repository.save(user1);
                resp = 1;
            }
        }
        if (resp == 1) {
            return 1;
        } else
            return 2;
    }
}
