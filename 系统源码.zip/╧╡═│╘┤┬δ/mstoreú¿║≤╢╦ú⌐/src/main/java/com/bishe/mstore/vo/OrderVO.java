package com.bishe.mstore.vo;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class OrderVO {
    private String shopName;
    private String shopIcon;
    private String specsName;
    private BigDecimal orderAmount;
}
