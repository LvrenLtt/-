package com.bishe.mstore.entity;

import lombok.Data;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.math.BigDecimal;

@Data
@Entity
public class Cart {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer cartId;
    private Integer shopId;
    private String userId;
    private String shopName;
    private Integer shopQuantity;
    private String shopIcon;
    private String specsName;
    private BigDecimal specsPrice;

}
