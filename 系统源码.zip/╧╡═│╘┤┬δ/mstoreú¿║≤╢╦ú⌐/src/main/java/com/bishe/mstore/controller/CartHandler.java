package com.bishe.mstore.controller;


import com.bishe.mstore.entity.Cart;
import com.bishe.mstore.entity.ShopSpecs;
import com.bishe.mstore.repository.CartRepository;
import com.bishe.mstore.repository.ShopSpecsRepository;
import com.bishe.mstore.vo.CartVO;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.beans.Transient;
import java.math.BigDecimal;
import java.util.List;

@RestController
@RequestMapping("/cart")
public class CartHandler {
    @Autowired
    private CartRepository cartRepository;
    @Autowired
    private ShopSpecsRepository shopSpecsRepository;
    @PostMapping("/create")
    public int save(@RequestBody CartVO cartVO){
        Cart cart = new Cart();
        BigDecimal a=new BigDecimal(100);
        BeanUtils.copyProperties(cartVO,cart);
        List<ShopSpecs> list=shopSpecsRepository.findAllBySpecsId(Integer.parseInt(cartVO.getSpecsId()));
        for (ShopSpecs shopSpecs:list){
            cart.setSpecsName(shopSpecs.getSpecsName());
            cart.setSpecsPrice((shopSpecs.getSpecsPrice()).divide(a));
        }
        cartRepository.save(cart);
        return 1;
    }
    @GetMapping("/findAllByUserId/{userId}")
    public List<Cart> findAllByUserId(
            @PathVariable("userId") String userId){
        List<Cart> list = cartRepository.findAllByUserId(userId);
        return list;
    }
//    @GetMapping("/find")
//    public List<Cart> findShop(){
//        List<Cart> list = cartRepository.findAll();
//        return list;
//    }
    @Transactional
    @GetMapping("/deleteBySpecsName/{specsName}")
    public int deleteBySpecsName(@PathVariable("specsName") String specsName){
            cartRepository.deleteBySpecsName(specsName);
            return 1;
        }

}


