package com.bishe.mstore.vo;

import lombok.Data;

import java.util.List;

@Data
public class TreeVO {
    private String k = "规格";
    private List<ShopSpecsVO> v;
    private String k_s = "s1";
}
