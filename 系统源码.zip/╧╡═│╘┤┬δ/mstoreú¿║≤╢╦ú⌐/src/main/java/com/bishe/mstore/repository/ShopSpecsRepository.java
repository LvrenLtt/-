package com.bishe.mstore.repository;

import com.bishe.mstore.entity.ShopSpecs;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ShopSpecsRepository extends JpaRepository<ShopSpecs,Integer> {
    public List<ShopSpecs> findAllByShopId(Integer shopId);

    public List<ShopSpecs> findAllBySpecsId(Integer specsId);

    List<ShopSpecs> findAllBySpecsName(String specsName);
}
