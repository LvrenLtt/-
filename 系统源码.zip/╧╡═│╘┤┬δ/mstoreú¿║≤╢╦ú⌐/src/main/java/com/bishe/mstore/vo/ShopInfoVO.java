package com.bishe.mstore.vo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;
import java.util.Map;

@Data
@AllArgsConstructor
public class ShopInfoVO {
    @JsonProperty("id")
    private Integer shopId;
    @JsonProperty("title")
    private String shopName;
    @JsonProperty("price")
    private String shopPrice;
    @JsonProperty("desc")
    private String shopDescription;
    private List<Map<String,String>> tag;
    @JsonProperty("thumb")
    private String shopIcon;
//    private Integer shopStatus;
}
