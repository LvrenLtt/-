package com.bishe.mstore.repository;

import com.bishe.mstore.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User,String> {
//    public User findByUserName(String username);
}
