package com.bishe.mstore.controller;


import com.bishe.mstore.entity.Admir;
import com.bishe.mstore.entity.OrderMaster;
import com.bishe.mstore.entity.ShopInfo;
import com.bishe.mstore.repository.AdmirRespository;
import com.bishe.mstore.repository.ShopInfoRepository;
import com.bishe.mstore.vo.CheckVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.DigestUtils;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/login")
public class AdmirHandler {
    @Autowired
    private AdmirRespository admirRespository;
    @Autowired
    private ShopInfoRepository shopInfoRepository;
    @PostMapping("/loginingA")
    public int checkS(@RequestBody Admir admir){
        int resp=0;
        String md5Password = DigestUtils.md5DigestAsHex(admir.getPassWord().getBytes());
        admir.setPassWord(md5Password);
        List<Admir> list = admirRespository.findAll();
        for (Admir seller1 : list) {
            if (seller1.getAdmirName().equals(admir.getAdmirName())&&seller1.getPassWord().equals(admir.getPassWord())) {
                resp= seller1.getAdmirId();
            }
        }
        return resp;
    }
    @PostMapping("/regAdmir")
    public int saveS( @RequestBody Admir admir){
        int resp=0;
        String md5Password = DigestUtils.md5DigestAsHex(admir.getPassWord().getBytes());
        admir.setPassWord(md5Password);
        List<Admir> list = admirRespository.findAll();
        for (Admir seller1 : list) {
            if(admir.getAdmirName().equals(seller1.getAdmirName())){
                resp=1;
            }
        }

        if (resp==1){
            return 1 ;
        }
        else{
            admirRespository.save(admir);
            return 2;
        }
    }
    @GetMapping("/findShopByShopStatus/{shopStatus}")
    public List<ShopInfo> findShopByShopStatus(
            @PathVariable("shopStatus") Integer shopStatus){
        List list=shopInfoRepository.findShopByShopStatus(shopStatus);
        return list;
    }
    @GetMapping("/updateShopStatusByShopId/{shopId}")
    public int updateShopStatusByShopId(
            @PathVariable("shopId") Integer shopId) {
        ShopInfo shopInfo = shopInfoRepository.getOne(shopId);
        shopInfo.setShopStatus(1);
        shopInfoRepository.save(shopInfo);
        return 1;

    }
    }
