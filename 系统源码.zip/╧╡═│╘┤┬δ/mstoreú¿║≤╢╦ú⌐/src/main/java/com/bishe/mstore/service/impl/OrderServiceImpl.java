package com.bishe.mstore.service.impl;

import com.bishe.mstore.dto.OrderDTO;
import com.bishe.mstore.entity.OrderMaster;
import com.bishe.mstore.entity.ShopInfo;
import com.bishe.mstore.entity.ShopSpecs;
import com.bishe.mstore.enums.PayStatusEnum;
import com.bishe.mstore.enums.ResultEnum;
import com.bishe.mstore.exception.ShopException;
import com.bishe.mstore.repository.OrderMasterRepository;
import com.bishe.mstore.repository.ShopInfoRepository;
import com.bishe.mstore.repository.ShopSpecsRepository;
import com.bishe.mstore.service.OrderService;
import com.bishe.mstore.service.ShopService;
import com.bishe.mstore.util.KeyUtil;
import com.bishe.mstore.vo.OrderDetailVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

@Service
@Slf4j
public class OrderServiceImpl implements OrderService {

    @Autowired
    private ShopSpecsRepository shopSpecsRepository;
    @Autowired
    private ShopInfoRepository shopInfoRepository;
    @Autowired
    private OrderMasterRepository orderMasterRepository;
    @Autowired
    private ShopService shopService;

    @Override
    public OrderDTO create(OrderDTO orderDTO) {
        OrderMaster orderMaster = new OrderMaster();
        BeanUtils.copyProperties(orderDTO,orderMaster);

        ShopSpecs shopSpecs = shopSpecsRepository.findById(orderDTO.getSpecsId()).get();
        if(shopSpecs == null){
            log.error("【创建订单】规格不存在,phoneSpecs={}",shopSpecs);
            throw new ShopException(ResultEnum.SPECS_NOT_EXIST);
        }
        BeanUtils.copyProperties(shopSpecs,orderMaster);

        ShopInfo shopInfo = shopInfoRepository.findById(shopSpecs.getShopId()).get();
        if(shopInfo == null){
            log.error("【创建订单】手机不存在,phoneInfo={}",shopInfo);
            throw new ShopException(ResultEnum.SHOP_NOT_EXIST);
        }
        BeanUtils.copyProperties(shopInfo,orderMaster);

        //计算总价
        BigDecimal orderAmount = new BigDecimal(0);
        orderAmount = shopSpecs.getSpecsPrice().divide(new BigDecimal(100))
                .multiply(new BigDecimal(orderDTO.getShopQuantity()))
                .add(orderAmount);
//                .add(new BigDecimal(10));
        orderMaster.setOrderAmount(orderAmount);

        //orderId
        orderMaster.setOrderId(KeyUtil.createUniqueKey());
        orderDTO.setOrderId(orderMaster.getOrderId());

        orderMaster.setUserId(orderDTO.getUserId());
        //payStatus
        orderMaster.setPayStatus(PayStatusEnum.UNPIAD.getCode());

        orderMasterRepository.save(orderMaster);

        shopService.subStock(orderDTO.getSpecsId(),orderDTO.getShopQuantity());

        return orderDTO;
    }

    @Override
    public OrderDetailVO findOrderDetailByOrderId(String orderId) {
        OrderDetailVO orderDetailVO = new OrderDetailVO();

        OrderMaster orderMaster = orderMasterRepository.findById(orderId).get();

        if(orderMaster == null){
            log.error("【查询订单】订单不存在,orderMaster={}",orderMaster);
            throw new ShopException(ResultEnum.ORDER_NOT_EXIST);
        }

        BeanUtils.copyProperties(orderMaster,orderDetailVO);
        orderDetailVO.setSpecsPrice(orderMaster.getSpecsPrice().divide(new BigDecimal(100))+".00");

        return orderDetailVO;
    }

    @Override
    public String pay(String orderId) {
        OrderMaster orderMaster = orderMasterRepository.findById(orderId).get();

        if(orderMaster == null){
            log.error("【支付订单】订单不存在,orderMaster={}",orderMaster);
            throw new ShopException(ResultEnum.ORDER_NOT_EXIST);
        }

        if(orderMaster.getPayStatus().equals(PayStatusEnum.UNPIAD.getCode())){
            orderMaster.setPayStatus(PayStatusEnum.PAID.getCode());
            orderMasterRepository.save(orderMaster);
        } else {
            log.error("【支付订单】订单已支付,orderMaster={}",orderMaster);
        }

        return orderId;
    }
}
