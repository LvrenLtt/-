package com.bishe.mstore.service;

import com.bishe.mstore.vo.DataVO;
import com.bishe.mstore.vo.ShopInfoVO;
import com.bishe.mstore.vo.SpecsPackageVO;

import java.util.List;

public interface ShopService {
    public DataVO findDataVO();
    public List<ShopInfoVO> findShopInfoVOByCategoryType(Integer categoryType);
    public SpecsPackageVO findSpecsByShopId(Integer shopId);
    public List<ShopInfoVO> findShopInfoVOByShopNameLike(String shopName);
    public void subStock(Integer specsId, Integer quantity);

}
