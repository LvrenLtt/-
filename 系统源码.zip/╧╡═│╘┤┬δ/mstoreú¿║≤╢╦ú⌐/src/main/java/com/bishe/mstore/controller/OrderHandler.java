package com.bishe.mstore.controller;

import com.bishe.mstore.dto.OrderDTO;
import com.bishe.mstore.entity.OrderMaster;
import com.bishe.mstore.exception.ShopException;
import com.bishe.mstore.form.OrderForm;
import com.bishe.mstore.repository.OrderMasterRepository;
import com.bishe.mstore.service.OrderService;
import com.bishe.mstore.util.KeyUtil;
import com.bishe.mstore.util.ResultVOUtil;
import com.bishe.mstore.vo.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.math.BigDecimal;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/order")
@Slf4j
public class OrderHandler {

    @Autowired
    private OrderService orderService;
    @Autowired
    private OrderMasterRepository orderMasterRepository;

    @PostMapping("/create")
    public ResultVO create(@Valid @RequestBody OrderForm orderForm, BindingResult bindingResult){
        if(bindingResult.hasErrors()){
            log.error("【创建订单】参数错误,orderForm={}",orderForm);
            throw new ShopException(bindingResult.getFieldError().getDefaultMessage());
        }

        OrderDTO orderDTO = new OrderDTO();
        orderDTO.setBuyerName(orderForm.getName());
        orderDTO.setBuyerPhone(orderForm.getTel());
        orderDTO.setBuyerAddress(orderForm.getAddress());
        orderDTO.setSpecsId(orderForm.getSpecsId());
        orderDTO.setShopQuantity(orderForm.getQuantity());
        orderDTO.setUserId(orderForm.getUserId());

        OrderDTO result = orderService.create(orderDTO);

        Map<String,String> map = new HashMap<>();
        map.put("orderId",result.getOrderId());

        return ResultVOUtil.success(map);
    }

    @PostMapping("/cartCreate")
    public String cartCreate(@RequestBody CartOrderVO cartOrderVO){
        OrderMaster orderMaster = new OrderMaster();
        BeanUtils.copyProperties(cartOrderVO,orderMaster);
        orderMaster.setShopId(0);
        orderMaster.setShopIcon("../static/cart.jpg");
        orderMaster.setShopName("若干");
        orderMaster.setShopQuantity(0);
        orderMaster.setSpecsId(0);
        orderMaster.setSpecsName("详情见购物车");
        orderMaster.setSpecsPrice(BigDecimal.valueOf(0));
        orderMaster.setOrderId(KeyUtil.createUniqueKey());
        orderMasterRepository.save(orderMaster);
        return orderMaster.getOrderId();
    }

    @GetMapping("/detail/{orderId}")
    public ResultVO findOrederDetail(
            @PathVariable("orderId") String orderId){
        return ResultVOUtil.success(orderService.findOrderDetailByOrderId(orderId));
    }
//    @GetMapping("/detailCart/{orderId}")
//    public OrderMaster findOrederDetail1 (
//            @PathVariable("orderId") String orderId){
//        DetailCartVO detailCartVO = new DetailCartVO();
//        OrderMaster orderMaster=orderMasterRepository.findAllByOrderId(orderId);
//        BeanUtils.copyProperties(detailCartVO,orderMaster);
//        return  orderMasterRepository.findAllByOrderId(orderId);
//    }

    @PutMapping("/pay/{orderId}")
    public ResultVO pay(
            @PathVariable("orderId") String orderId){
        Map<String,String> map = new HashMap<>();
        map.put("orderId",orderService.pay(orderId));
        return ResultVOUtil.success(map);
    }
    @GetMapping("/findOrderByPayStatus/{payStatus}")
    public List<OrderMaster> findOrderByPayStatus(
            @PathVariable("payStatus") Integer payStatus){
      List list=orderMasterRepository.findOrderByPayStatus(payStatus);
      return list;
    }
    @GetMapping("/updatePayStatusByOrderId/{orderId}")
    public int updatePayStatusByOrderId(
            @PathVariable("orderId") String orderId){
        OrderMaster orderMaster = orderMasterRepository.getOne(orderId);
        orderMaster.setPayStatus(1);
        orderMasterRepository.save(orderMaster);
        return 1;
    }
    @GetMapping("/updatePayStatusByOrderId1/{orderId}")
    public int updatePayStatusByOrderId1(
            @PathVariable("orderId") String orderId){
        OrderMaster orderMaster = orderMasterRepository.getOne(orderId);
        orderMaster.setPayStatus(2);
        orderMasterRepository.save(orderMaster);
        return 1;
    }
    @GetMapping("/updatePayStatusByOrderId2/{orderId}")
    public int updatePayStatusByOrderId2(
            @PathVariable("orderId") String orderId){
        OrderMaster orderMaster = orderMasterRepository.getOne(orderId);
        orderMaster.setPayStatus(3);
        orderMasterRepository.save(orderMaster);
        return 1;
    }
}
