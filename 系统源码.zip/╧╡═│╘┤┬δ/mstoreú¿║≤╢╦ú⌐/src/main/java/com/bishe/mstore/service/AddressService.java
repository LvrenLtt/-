package com.bishe.mstore.service;

import com.bishe.mstore.form.AddressForm;
import com.bishe.mstore.vo.AddressVO;

import java.util.List;

public interface AddressService {
    public List<AddressVO> findAll();
    public void saveOrUpdate(AddressForm addressForm);
}
