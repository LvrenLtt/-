package com.bishe.mstore.controller;

import com.bishe.mstore.entity.Seller;
import com.bishe.mstore.repository.SellerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.DigestUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/login")
public class SellerHandler {
    @Autowired
    private SellerRepository sellerRepository;
    @PostMapping("/loginingS")
    public int checkS(@RequestBody Seller seller){
        int resp=0;
        String md5Password = DigestUtils.md5DigestAsHex(seller.getSellerPass().getBytes());
        seller.setSellerPass(md5Password);
        List<Seller> list = sellerRepository.findAll();
        for (Seller seller1 : list) {
            if (seller1.getSellerName().equals(seller.getSellerName())&&seller1.getSellerPass().equals(seller.getSellerPass())) {
                resp= seller1.getSellerId();
            }
        }
        return resp;
    }
    @PostMapping("/regseller")
    public int saveS( @RequestBody Seller seller){
        int resp=0;
        String md5Password = DigestUtils.md5DigestAsHex(seller.getSellerPass().getBytes());
        seller.setSellerPass(md5Password);
        List<Seller> list = sellerRepository.findAll();
        for (Seller seller1 : list) {
            if(seller.getSellerName().equals(seller1.getSellerName())){
                resp=1;
            }
        }

        if (resp==1){
            return 1 ;
        }
        else{
            sellerRepository.save(seller);
            return 2;
        }
    }
   
}
