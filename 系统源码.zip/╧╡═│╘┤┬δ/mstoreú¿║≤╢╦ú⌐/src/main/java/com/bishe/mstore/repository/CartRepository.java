package com.bishe.mstore.repository;

import com.bishe.mstore.entity.Cart;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CartRepository extends JpaRepository<Cart,Integer> {
   public List<Cart> findAllByUserId(String userId);
   public int deleteBySpecsName(String specsName);
}
