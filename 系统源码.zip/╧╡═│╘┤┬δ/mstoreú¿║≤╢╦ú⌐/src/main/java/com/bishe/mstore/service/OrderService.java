package com.bishe.mstore.service;

import com.bishe.mstore.dto.OrderDTO;
import com.bishe.mstore.vo.OrderDetailVO;

public interface OrderService {
    public OrderDTO create(OrderDTO orderDTO);
    public OrderDetailVO findOrderDetailByOrderId(String orderId);
    public String pay(String orderId);
}
