package com.bishe.mstore.entity;

import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

@Data
@Entity
@EntityListeners(AuditingEntityListener.class)
public class ShopInfo {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer shopId;
    private String shopName;
    private BigDecimal shopPrice;
    private String shopDescription;
    private Integer shopStock;
    private String shopIcon;
    private Integer categoryType;
    private String shopTag;
    @Column(name = "create_time")
    @CreatedDate
    private Date createTime;
    @LastModifiedDate
    @Column(name = "update_time")
    private Date updateTime;
    private Integer shopStatus;
}
