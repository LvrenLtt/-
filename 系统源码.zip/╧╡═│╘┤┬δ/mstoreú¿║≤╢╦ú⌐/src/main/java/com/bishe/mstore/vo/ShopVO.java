package com.bishe.mstore.vo;

import lombok.Data;

import java.math.BigDecimal;
@Data
public class ShopVO {

    private String shopName;
    private BigDecimal shopPrice;
    private String shopDescription;
    private Integer shopStock;
    private String shopIcon;
    private Integer categoryType;
    private String shopTag;
    private Integer shopStatus;
}
