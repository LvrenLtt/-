package com.bishe.mstore.service.impl;

import com.bishe.mstore.entity.ShopCategory;
import com.bishe.mstore.entity.ShopInfo;
import com.bishe.mstore.entity.ShopSpecs;
import com.bishe.mstore.enums.ResultEnum;
import com.bishe.mstore.exception.ShopException;
import com.bishe.mstore.repository.ShopCategoryRepository;
import com.bishe.mstore.repository.ShopInfoRepository;
import com.bishe.mstore.repository.ShopSpecsRepository;
import com.bishe.mstore.service.ShopService;
import com.bishe.mstore.util.ShopUtil;
import com.bishe.mstore.vo.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@Slf4j
public class ShopServiceImpl implements ShopService {

    @Autowired
    private ShopCategoryRepository shopCategoryRepository;
    @Autowired
    private ShopInfoRepository shopInfoRepository;
    @Autowired
    private ShopSpecsRepository shopSpecsRepository;

    @Override
    public DataVO findDataVO() {
        DataVO dataVO = new DataVO();
        //类型
        List<ShopCategory> shopCategoryList = shopCategoryRepository.findAll();
        //常规写法
//        List<PhoneCategoryVO> phoneCategoryVOList = new ArrayList<>();
//        for (PhoneCategory phoneCategory : phoneCategoryList) {
//            PhoneCategoryVO phoneCategoryVO = new PhoneCategoryVO();
//            phoneCategoryVO.setCategoryName(phoneCategory.getCategoryName());
//            phoneCategoryVO.setCategoryType(phoneCategory.getCategoryType());
//            phoneCategoryVOList.add(phoneCategoryVO);
//        }
        //stream
        List<ShopCategoryVO> shopCategoryVOList =  shopCategoryList.stream()
                .map(e -> new ShopCategoryVO(
                        e.getCategoryName(),
                        e.getCategoryType()
                )).collect(Collectors.toList());

        dataVO.setCategories(shopCategoryVOList);

        List<ShopInfo> shopInfoList = shopInfoRepository.findAllByCategoryType(shopCategoryList.get(0).getCategoryType());
        List<ShopInfo> phoneInfoList = new ArrayList<>();
        for (ShopInfo shopInfo:shopInfoList){
            if (shopInfo.getShopStatus()==1){
                phoneInfoList.add(shopInfo);
            }
        }
        //stream
        List<ShopInfoVO> shopInfoVOList = phoneInfoList.stream()
                .map(e -> new ShopInfoVO(
                        e.getShopId(),
                        e.getShopName(),
                        e.getShopPrice()+".00",
                        e.getShopDescription(),
                        ShopUtil.createTag(e.getShopTag()),
                        e.getShopIcon()
                )).collect(Collectors.toList());

        dataVO.setShops(shopInfoVOList);

        return dataVO;
    }

    @Override
    public List<ShopInfoVO> findShopInfoVOByCategoryType(Integer categoryType) {
        List<ShopInfo> shopInfoList = shopInfoRepository.findAllByCategoryType(categoryType);
        List<ShopInfo> phoneInfoList = new ArrayList<>();
        for (ShopInfo shopInfo:shopInfoList){
            if (shopInfo.getShopStatus()==1){
                phoneInfoList.add(shopInfo);
            }
        }
        List<ShopInfoVO> shopInfoVOList = phoneInfoList.stream()
                .map(e -> new ShopInfoVO(
                        e.getShopId(),
                        e.getShopName(),
                        e.getShopPrice()+".00",
                        e.getShopDescription(),
                        ShopUtil.createTag(e.getShopTag()),
                        e.getShopIcon()
                )).collect(Collectors.toList());
        return shopInfoVOList;
    }

    @Override
    public SpecsPackageVO findSpecsByShopId(Integer shopId) {
        ShopInfo shopInfo = shopInfoRepository.findById(shopId).get();
        List<ShopSpecs> shopSpecsList = shopSpecsRepository.findAllByShopId(shopId);

        //tree
        List<ShopSpecsVO> shopSpecsVOList = new ArrayList<>();
        List<ShopSpecsCasVO> shopSpecsCasVOList = new ArrayList<>();
        ShopSpecsVO shopSpecsVO;
        ShopSpecsCasVO shopSpecsCasVO;
        for (ShopSpecs shopSpecs : shopSpecsList) {
            shopSpecsVO = new ShopSpecsVO();
            shopSpecsCasVO = new ShopSpecsCasVO();
            BeanUtils.copyProperties(shopSpecs,shopSpecsVO);
            BeanUtils.copyProperties(shopSpecs,shopSpecsCasVO);
            shopSpecsVOList.add(shopSpecsVO);
            shopSpecsCasVOList.add(shopSpecsCasVO);
        }
        TreeVO treeVO = new TreeVO();
        treeVO.setV(shopSpecsVOList);
        List<TreeVO> treeVOList = new ArrayList<>();
        treeVOList.add(treeVO);

        SkuVO skuVO = new SkuVO();
        Integer price = shopInfo.getShopPrice().intValue();
        skuVO.setPrice(price+".00");
        skuVO.setStock_num(shopInfo.getShopStock());
        skuVO.setTree(treeVOList);
        skuVO.setList(shopSpecsCasVOList);

        SpecsPackageVO specsPackageVO = new SpecsPackageVO();
        specsPackageVO.setSku(skuVO);
        Map<String,String> goods = new HashMap<>();
        goods.put("picture",shopInfo.getShopIcon());
        specsPackageVO.setGoods(goods);

        return specsPackageVO;
    }
    @Override
    public List<ShopInfoVO> findShopInfoVOByShopNameLike(String shopName) {
        List<ShopInfo> shopInfoList = shopInfoRepository.findAllByShopNameLike("%"+shopName+"%");
        List<ShopInfoVO> shopInfoVOList = shopInfoList.stream()
                .map(e -> new ShopInfoVO(
                        e.getShopId(),
                        e.getShopName(),
                        e.getShopPrice()+".00",
                        e.getShopDescription(),
                        ShopUtil.createTag(e.getShopTag()),
                        e.getShopIcon()
                )).collect(Collectors.toList());
        return shopInfoVOList;
    }

    @Override
    public void subStock(Integer specsId, Integer quantity) {
        ShopSpecs shopSpecs = shopSpecsRepository.findById(specsId).get();
        ShopInfo shopInfo = shopInfoRepository.findById(shopSpecs.getShopId()).get();
        Integer result = shopSpecs.getSpecsStock() - quantity;
        if(result < 0){
            log.error("【扣库存】库存不足");
            throw new ShopException(ResultEnum.SHOP_STOCK_ERROR);
        }

        shopSpecs.setSpecsStock(result);
        shopSpecsRepository.save(shopSpecs);

        result = shopInfo.getShopStock() - quantity;
        if(result < 0){
            log.error("【扣库存】库存不足");
            throw new ShopException(ResultEnum.SHOP_STOCK_ERROR);
        }

        shopInfo.setShopStock(result);
        shopInfoRepository.save(shopInfo);
    }
}
