package com.bishe.mstore.exception;


import com.bishe.mstore.enums.ResultEnum;

public class ShopException extends RuntimeException {
    public ShopException(ResultEnum resultEnum) {
        super(resultEnum.getMsg());
    }

    public ShopException(String error) {
        super(error);
    }
}
