import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '../views/Home.vue'
import AddressList from '../views/AddressList'
import AddressNew from '../views/AddressNew'
import AddressEdit from '../views/AddressEdit'
import Detail from '../views/Detail'
import Success from '../views/Success'
import Info from '../views/Info'
import My from '../views/My'
import Login from '../views/Login'
import Register from '../views/Register'
import Ad from '../views/ad'
import ShouYe from '../views/Shouye'
import Search from  '../views/Search'
import Select from  '../views/Select'
import Seller from '../views/Seller'
import Admir from '../views/Admir'
import AddressListCart from  '../views/addressListCart'
import Daifukuan from '../views/daifukuan'
import Daifahuo from '../views/daifahuo'
import Daishouhuo from '../views/daishouhuo'
import Yiwancheng from '../views/yiwancheng'
import LoginSeller from '../views/LoginSeller'
import RegSeller from  '../views/RegSeller'
import OrderM from '../views/OrderM'
import  ChangePass from  '../views/ChangePass'
import ShopEdit from '../views/ShopEdit'
import SpecsEdit from  '../views/SpecsEdit'
import AdmirLogin from '../views/AdmirLogin'
import AddShop from '../views/AddShop'
import Add from '../views/Add'
Vue.use(VueRouter)
const routes = [
    { path: '/',
        name: 'Ad',
        component: Ad},
    {
        path: '/home',
        name: 'Home',
        component: Home
    },
    {
        path: '/about',
        name: 'About',
        // route level code-splitting
        // this generates a separate chunk (about.[hash].js) for this route
        // which is lazy-loaded when the route is visited.
        component: () => import(/* webpackChunkName: "about" */ '../views/About.vue')
    },
    {
        path: '/addressList',
        name: '地址列表',
        component: AddressList
    },
    {
        path: '/addressListCart',
        name: 'addcart',
        component: AddressListCart
    },
    {
        path: '/addressNew',
        name: '新增地址',
        component: AddressNew
    },
    {
        path: '/addressEdit',
        name: '编辑地址',
        component: AddressEdit
    },
    {
        path: '/detail',
        name: '订单详情',
        component: Detail
    },
    {
        path: '/success',
        name: '付款成功',
        component: Success
    },
    {
        path: '/info',
        name: '订单信息',
        component: Info
    },
    {
        path: '/my',
        name: '我的',
        component: My
    },
    {
        path: '/login',
        name: '登录',
        component: Login
    },
    {
        path:'/loginseller',
        component:LoginSeller
    },
    {
        path: '/register',
        name: '注册',
        component: Register
    },
    {
        path:'/regseller',
        component:RegSeller
    },
    {
        path:'/shouye',
        name:'首页',
        component:ShouYe
    },
    {
        path:'/search',
        name:'搜索结果',
        component:Search
    },
    {
    path:'/select' ,
    component:Select
    },
    {
        path:'/seller',
        component:Seller
    },
    {
        path:'/admir',
        component:Admir
    },
    {
        path:'/daifahuo',
        component:Daifahuo
    },
    {
        path:'/daifukuan',
        component:Daifukuan
    },
    {
        path:'/daishouhuo',
        component:Daishouhuo
    },
    {
        path:'/yiwancheng',
        component:Yiwancheng
    },
    {
    path:'/orderm',
        component:OrderM
    },
    {
        path:'/change',
        component:ChangePass
    },
    {
        path:'/shopedit',
        component:ShopEdit
    },
    {
        path:'/specsedit',
        component:SpecsEdit
    },
    {
        path:'/admirlogin',
        component:AdmirLogin
    },
    {
        path:'/addshop',
        component:AddShop
    },
    {
        path:'/add',
        component:Add
    }
]

const router = new VueRouter({
    mode: 'history',
    base: process.env.BASE_URL,
    routes
})

export default router
