<template>
    <div>
        <van-image
                width="100"
                height="100"
                src="../static/paysuccess.png"
        />
        <van-cell :title="amount"/>
        <van-cell-group class="goods-cell-group">
            <van-cell class="goods-express">
                <van-col span="21">配送方式</van-col>
                <van-col>快递</van-col>
            </van-cell>
        </van-cell-group>
        <van-button type="primary" size="large" @click="showInfo">查看订单详情</van-button>
        <van-tabbar v-model="active">
            <van-tabbar-item badge="3">
                <span>自定义</span>
                <template #icon="props">
                    <img :src="props.active ? icon.active : icon.inactive" />
                </template>
            </van-tabbar-item>
            <van-row>
                <van-col span="24">
                    <van-tabs sticky title-active-color="#E32DAB" color="#E32DAB" :line-width="100" :line-height="6"></van-tabs>
                </van-col>
            </van-row>
            <van-tabbar-item icon="home-o"@click="shouye">首页</van-tabbar-item>
            <van-tabbar-item icon="cart-o" @click="fenlei">购物车</van-tabbar-item>
            <van-tabbar-item icon="https://b.yzcdn.cn/vant/icon-demo-1126.png" @click="wode">我的</van-tabbar-item>
        </van-tabbar>
    </div>
</template>

<script>
    export default {
        name: "Success",
        data() {
            return {
                orderId: null,
                amount: null
            }
        },
        created(){
            this.orderId = this.$route.query.orderId
            this.amount = this.$route.query.amount
        },
        methods:{
            showInfo(){
                this.$router.push('/info?orderId='+this.orderId)
            },
            shouye(){
                this.$router.push('/shouye')
            },
            wode(){
                this.$router.push('/my')
            },
            fenlei(){
                this.$router.push('/home')
            }
        }
    }
</script>

<style scoped>

</style>