<template>
    <div>
        <h3>

        </h3>
        <van-tabbar v-model="active">
            <van-tabbar-item badge="3">
                <span>自定义</span>
                <template #icon="props">
                    <img :src="props.active ? icon.active : icon.inactive" />
                </template>
            </van-tabbar-item>
            <van-tabbar-item icon="home-o"@click="shop">商品管理</van-tabbar-item>
            <van-tabbar-item icon="plus"@click="add">商品上架</van-tabbar-item>
            <van-tabbar-item icon="search" @click="orderM">订单管理</van-tabbar-item>
            <!--<van-tabbar-item icon="https://b.yzcdn.cn/vant/icon-demo-1126.png" @click="wode">我的</van-tabbar-item>-->
        </van-tabbar>

        <van-row>
            <van-col span="24">
                <van-tabs  style="margin-bottom: 70px" @click="onClick" sticky title-active-color="#E32DAB" color="#E32DAB" :line-width="100" :line-height="2">

                    <van-tab v-for="index in categories.length" :title="categories[index-1].name" class="tab":key="index">

                        <van-card v-for="(item,index) in shops"
                                  :price="item.price"
                                  :desc="item.desc"
                                  :title="item.title"
                                  :thumb="item.thumb"
                                  :key="index"
                        >
                            <template #tags>
                                <van-tag v-for="tag in item.tag" color="#f2826a" style="margin-left: 5px;" :key="index">{{tag.name}}</van-tag>
                            </template>
                            <template #footer>
                                <van-button round type="info" size="mini" @click="edit(index)">编辑</van-button>
                                <van-button round type="info" size="mini" @click="del(index)">删除</van-button>
                            </template>
                        </van-card>

                    </van-tab>
                </van-tabs>
            </van-col>
        </van-row>


    </div>
</template>

<script>
    import {
        Toast,
        PullRefresh,
        Swipe,
        SwipeItem
    } from 'vant';
    export default {
        comments:{
            [PullRefresh.name]: PullRefresh,
            [Swipe.name]: Swipe,
            [SwipeItem.name]: SwipeItem
        },
        data() {
            return {
                images: [
                    '../static/e84a2e03-7f19-41d2-98a5-a5c16b7e252d.jpg',
                    '../static/e84a2e03-7f19-41d2-98a5-a5c16b7e252d.jpg',
                    '../static/e84a2e03-7f19-41d2-98a5-a5c16b7e252d.jpg',
                    '../static/e84a2e03-7f19-41d2-98a5-a5c16b7e252d.jpg',
                ],
                categories: '',
                shops: '',
                show: true,
                sku: '',
                goods: '',
                value: ''
            }
        },
        created(){
            if (localStorage.getItem('sid')===null){
                let instance = Toast('请先登录');
                this.$router.push('/loginseller')
            }
            const _this = this
            axios.get('http://localhost:8181/shop/index').then(function (resp) {
                console.log(resp.data)
                _this.shops = resp.data.data.shops
                _this.categories = resp.data.data.categories
            })
        },
        methods: {
            onClick(index) {
                const _this = this
                axios.get('http://localhost:8181/shop/findByCategoryType/'+this.categories[index].type).then(function (resp) {
                    _this.shops = resp.data.data
                })
            },
            edit(index){
                let data = JSON.stringify(this.shops[index])
                let data1 = JSON.stringify(this.categories[index])
                this.$router.push({path:'/shopedit',query:{shop:data,categories:data1}})

            },
            del(index){
                this.show = true
                const _this = this
                axios.post('http://localhost:8181/shop/deleteByShopId/'+this.shops[index].id).then(function (resp) {
                    console.log(resp)
                })
            },

            shop(){
                this.$router.push('/seller')
            },
            orderM(){
                this.$router.push('/orderm')
            },
            add(){
                this.$router.push('/add')

            }


        },

    }
</script>
<style scoped>
    .my-swipe .van-swipe-item {
        color: #f2f3f5;
        font-size: 20px;
        line-height: 150px;
        text-align: center;
        background-color: #EE3E3B;
    }
</style>