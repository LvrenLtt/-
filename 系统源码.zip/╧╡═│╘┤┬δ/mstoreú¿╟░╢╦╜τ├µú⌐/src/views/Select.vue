<template>
    <div class="a">
        <van-row>
        <van-col span="8"><van-button round type="info" @click="buy" >我是买家</van-button></van-col>
            <van-col span="8">  <van-button round type="info" @click="sell">我是卖家</van-button></van-col>
            <v-col span="8"> <van-button round type="info" @click="admir">管理员</van-button></v-col>
        </van-row>
    </div>
</template>
<script>
    export default {
        methods:{
            buy(){
                this.$router.push('/login')
            },
            sell(){
                this.$router.push('/loginseller')
            },
            admir(){
                this.$router.push('/admirlogin')
            }
        }
    }
</script>

<style scoped>
.a{
   margin: 50% auto;
    vertical-align: middle;

}
</style>