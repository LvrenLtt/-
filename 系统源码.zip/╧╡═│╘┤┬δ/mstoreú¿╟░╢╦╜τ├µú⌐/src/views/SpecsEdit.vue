<template>
    <div>
        <van-field v-model="shopName" label="商品名" />
        <van-field v-model="specsName" label="规格名" />
        <van-field v-model="specsStock" label="库存" />
        <van-field v-model="specsPrice" label="价格" />
        <van-field v-model="specsIcon" label="小图" />
        <van-field v-model="specsPreview" label="预览图" />

        <van-button type="primary" @click="submit">提交</van-button>
    </div>
</template>

<script>
    export default {
        name: "SpecsEdit",
        data(){
            return{
                // specsform:{
                shopName: this.$route.query.shopName,
                specsStock: '',
                specsPrice: '',
                specsName: '',
                specsIcon: '',
                specsPreview: '',

                // }
            }
        },
        methods:{
            submit(){
                const _this = this
                 let  specsform={
                     shopName: this.$route.query.shopName,
                     specsStock: this.specsStock,
                     specsPrice: this.specsPrice,
                     specsName: this.specsName,
                     specsIcon: this.specsIcon,
                     specsPreview: this.specsPreview,
                 }
                 console.log(specsform)
                axios.post('http://localhost:8181/shop/saveSpecs',specsform).then(function (resp) {
                    console.log(resp)
                    if (resp.data===1){
                        _this.$router.push('/seller')
                    }
                })

            }
        }
    }
</script>

<style scoped>

</style>