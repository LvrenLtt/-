<template>
  <div>
      <h3 class="a">购物车</h3>
    <van-tabbar v-model="active">
      <van-tabbar-item badge="3">
        <span>自定义</span>
        <template #icon="props">
          <img :src="props.active ? icon.active : icon.inactive" />
        </template>
      </van-tabbar-item>
      <van-tabbar-item icon="home-o"@click="shouye">首页</van-tabbar-item>
      <van-tabbar-item icon="cart-o" @click="fenlei">购物车</van-tabbar-item>
      <van-tabbar-item icon="https://b.yzcdn.cn/vant/icon-demo-1126.png" @click="wode">我的</van-tabbar-item>
    </van-tabbar>

    <div class="box">
      <div class="block" style="margin-bottom: 70px">
        <div class="shop">
          <div class="row" v-for="(item,i) in goodsList" :key="i">
            <div class="pic" @click="selectGoods(index,i)">
              <img
                      :src="item.isGoods == 1 ? '../static/1.png' :'../static/2.png'"
                      alt />
            </div>
            <div class="detail">
              <div class="photo">
                <img :src="item.shopIcon" class="img1" alt />
              </div>
              <div class="info">
                <div class="title">{{item.shopName}}</div>
                <div class="norm">{{item.specsName}}</div>
                <div class="rol">
                  <span class="amount">￥{{item.specsPrice}}</span>
                  <van-stepper v-model="item.shopQuantity" disable-input @change="countNum()" />
                  <div class="del" @click="delGoods(index,i)">
                    <img src="../../public/static/3.png" alt />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="close">
          <div class="all" @click="selectAll()">
            <div class="pic">
              <img
                      :src="isAll == 1 ? '../static/1.png' :'../static/2.png'"
                      alt />
            </div>
            <span>全选</span>
          </div>
          <div class="refer">
            <div class="total">
              <span>合计:</span>
              <span>￥{{allPrice}}</span>
            </div>
            <div class="settlement" @click="com">结算</div>
          </div>
        </div>
      </div>
    </div>
  </div>


</template>

<script>
    import {
        Toast,
        PullRefresh,
        Swipe,
        SwipeItem
    } from 'vant';
    export default {
        comments:{
            [PullRefresh.name]: PullRefresh,
            [Swipe.name]: Swipe,
            [SwipeItem.name]: SwipeItem
        },
        data() {
            return {
                isAll: 0,
                allPrice: 0,
                goodsList: {
                    isGoods: 0,
                    shopIcon: '',
                    shopId: '',
                    shopName: '',
                    specsName: '',
                    specsPrice: '',
                    shopQuantity: '',
                } ,
            };
        },
        created(){
            if (localStorage.getItem('id')===null){
                let instance = Toast('请先登录');
                this.$router.push('/login')
            }
            const _this = this
            axios.get('http://localhost:8181/cart/findAllByUserId/'+localStorage.getItem('id')).then(function (resp) {
                console.log(resp)
                _this.goodsList = resp.data

            })
        },
        mounted() {},
        methods: {
            delGoods(index, i) {
                var list = this.goodsList;
               console.log(list[i].specsName)
                this.watchAll();
                this.countPrice();
                axios.get('http://localhost:8181/cart/deleteBySpecsName/'+list[i].specsName).then(function (resp){
                    if(resp.data === 1){
                        let instance = Toast('删除成功');
                        setTimeout(() => {
                            instance.close();
                            location.reload()
                        }, 1000)
                    }
                })
            },

            // 选择商品
            selectGoods(index, i) {
                var list = this.goodsList;
                if (list[i].isGoods == 0) {
                    list[i].isGoods = 1;
                } else {
                    list[i].isGoods = 0;
                }
                this.watchAll();
                this.countPrice();
            },

            // 全选
            selectAll() {
                var list = this.goodsList;
                if (list.length == 0) {
                    this.isAll = 0;
                    return;
                }
                if (this.isAll == 0) {
                    this.isAll = 1;
                    for (let i in list) {
                        list[i].isGoods = 1;
                    }
                } else {
                    this.isAll = 0;
                    for (let i in list) {
                        list[i].isGoods = 0;
                    }
                }
                this.countPrice();
            },

            // 监听全选
            watchAll() {
                var list = this.goodsList;
                if (list.length == 0) {
                    this.isAll = 0;
                    return;
                }
                var result = [];
                for (let i in list) {
                        result.push(list[i].isGoods);
                    }
                var anti = result.map((item) => item).indexOf(0);
                if (anti == -1) {
                    this.isAll = 1;
                } else {
                    this.isAll = 0;
                }
            },

            // 更改商品数量
            countNum() {
                this.countPrice();
            },

            // 计算总价格
            countPrice() {
                let count = 0;
                var list = this.goodsList;
                for (let i in list) {
                        if (list[i].isGoods == 1) {
                            count += list[i].specsPrice * list[i].shopQuantity;
                        }
                }
                this.allPrice = count;
            },
            com(){
                localStorage.setItem('orderAmount',this.allPrice)

                this.$router.push('/addressListCart')

            },

            shouye(){
                this.$router.push('/shouye')
            },
            wode(){
                this.$router.push('/my')
            },
            fenlei(){
                this.$router.push('/home')
            }
            },
        }

</script>
<style lang="less" scoped>
  .box {
    /*position: relative;*/
    /*width: 100%;*/
    /*height: 100%;*/
    /*padding: 30px;*/
    /*box-sizing: border-box;*/
    /*background: #fff;*/
    /*margin-bottom: 104px;*/
  }

  .shop {
    margin-bottom: 6px;
    box-shadow: 0px 8px 20px 0px rgba(97, 97, 97, 0.19);
    border-radius: 12px;
    padding: 10px;
    width: 376px;
    box-sizing: border-box;
  }

  .line {
    display: flex;
    align-items: center;
  }

  .pic {
    width: 40px;
    height: 40px;
  }

  img {
    width: 30px;
    height: 30px;
    object-fit: cover;
  }
  .img1{
    width: 88px;
    height: 88px;
  }
  .line div:nth-child(2) {
    font-size: 24px;
    margin-left: 16px;
  }

  .row {
    display: flex;
    align-items: center;
    margin-top: 10px;
    width: 375.2px;
    height: 128px;
  }

  .detail {
    width: 376px;
    height: 128px;

    margin-left: 0px;
    padding: 20px;
    box-sizing: border-box;
    display: flex;
    align-items: center;
    justify-content: space-between;
  }

  .photo {
    width: 132px;
    height: 132px;
  }

  .info {
    width: 74%;
    height: 100%;
    display: flex;
    justify-content: space-around;
    flex-direction: column;
    text-align: left;
  }

  .title {
    font-size: 15px;
  }

  .norm {
    font-size: 8px;
    color: #999999;
  }

  .rol {
    display: flex;
    align-items: center;
    justify-content: space-between;
  }

  .amount {
    font-size: 15px;
    font-weight: 100;
    color: #ff3b30;
  }

  .del {
    width: 30px;
    display: flex;
    align-items: center;
  }

  .close {
    position: fixed;
    bottom: 49px;
    left: 0;
    width: 389px;
    height: 50px;
    border-top: 1px solid #eeeeee;
    background: #fff;
    display: flex;
    align-items: center;
    justify-content: space-between;
  }

  .all {
    display: flex;
    align-items: center;
    margin-left: 8px;
  }

  .all span {
    color: #999999;
    font-size: 2px;
    margin-left: 5px;
  }

  .refer {
    display: flex;
    align-items: center;
    height: 100%;
  }

  .total {
    display: flex;
    align-items: center;
  }

  .total span:nth-child(1) {
    font-size: 2px;
  }

  .total span:nth-child(2) {
    font-size: 8px;
    font-weight: 600;
    color: #ff3b30;
  }

  .settlement {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 160px;
    height: 50px;
    background: #ff3b30;
    color: #fff;
    font-size: 3px;
    margin-left: 15px;
  }

</style>