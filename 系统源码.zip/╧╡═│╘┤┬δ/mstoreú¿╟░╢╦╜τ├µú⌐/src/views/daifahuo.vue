<template>
    <div>
        <van-tabbar v-model="active">
            <van-tabbar-item badge="3">
                <span>自定义</span>
                <template #icon="props">
                    <img :src="props.active ? icon.active : icon.inactive" />
                </template>
            </van-tabbar-item>
            <van-tabbar-item icon="home-o"@click="shouye">首页</van-tabbar-item>
            <van-tabbar-item icon="cart-o" @click="fenlei">购物车</van-tabbar-item>
            <van-tabbar-item icon="https://b.yzcdn.cn/vant/icon-demo-1126.png" @click="wode">我的</van-tabbar-item>
        </van-tabbar>

        <van-row>
            <van-col span="24">
                <van-card v-for="(item,index) in goodsList"
                          :price="item.orderAmount"
                          :desc="item.specsName"
                          :title="item.shopName"
                          :thumb="item.shopIcon"
                          :key="index"
                >
                    <template #tags>
                        <van-tag v-for="tag in item.tag" color="#f2826a" style="margin-left: 5px;" :key="index">{{tag.name}}</van-tag>
                    </template>
                    <template #footer>
                        <van-button round type="info" size="mini" >等待发货</van-button>
                        <van-button round type="info" size="mini"@click="watch(index)"  >订单详情</van-button>
                    </template>
                </van-card>


            </van-col>
        </van-row>

    </div>
</template>

<script>
    import {
        Toast,
        PullRefresh,
        Swipe,
        SwipeItem
    } from 'vant';
    export default {
        comments:{
            [PullRefresh.name]: PullRefresh,
            [Swipe.name]: Swipe,
            [SwipeItem.name]: SwipeItem
        },
        data() {
            return {
                images: [
                    '../static/e84a2e03-7f19-41d2-98a5-a5c16b7e252d.jpg',
                    '../static/e84a2e03-7f19-41d2-98a5-a5c16b7e252d.jpg',
                    '../static/e84a2e03-7f19-41d2-98a5-a5c16b7e252d.jpg',
                    '../static/e84a2e03-7f19-41d2-98a5-a5c16b7e252d.jpg',
                ],
                categories: '',
                goodsList: {
                    isGoods: 0,
                    shopIcon: '',
                    shopId: '',
                    shopName: '',
                    specsName: '',
                    orderAmount: '',
                    shopQuantity: '',
                    orderId:''
                },
                show: true,
                sku: '',
                goods: '',
                value: ''
            }
        },
        created(){
            if (localStorage.getItem('id')===null){
                let instance = Toast('请先登录');
                this.$router.push('/login')
            }
            const _this = this
            axios.get('http://localhost:8181/order/findOrderByPayStatus/1').then(function (resp) {
                console.log(resp)
                 _this.goodsList = resp.data

            })
        },
        methods: {
            shouye(){
                this.$router.push('/shouye')
            },
            wode(){
                this.$router.push('/my')
            },
            fenlei(){
                this.$router.push('/home')
            },
            watch(index){
                 this.$router.push('/info?orderId='+this.goodsList[index].orderId)


    }
        },

    }
</script>
<style scoped>
    .my-swipe .van-swipe-item {
        color: #f2f3f5;
        font-size: 20px;
        line-height: 150px;
        text-align: center;
        background-color: #EE3E3B;
    }
</style>