<template>
    <div>
        <van-field v-model="shopName" label="商品名" />
        <van-field v-model="shopPrice" label="价格" />
        <van-field v-model="categoryType" label="种类编号" />
        <van-field v-model="shopDescription" label="描述信息" />
        <van-field v-model="shopStock" label="库存" />
        <van-field v-model="shopIcon" label="图片" />
        <van-field v-model="shopTag" label="标签" />
        <van-button type="primary" @click="submit">填写规格分类</van-button>

    </div>
</template>

<script>
    import Toast from 'vant'
    export default {
        name: "ShopEdit",
        data(){
            return{
                shopName:'',
                shopIcon:'',
                shopPrice:'',
                categoryType:'',
                shopDescription:'',
                shopStock:'',
                shopTag:'',
            }
        },
        created(){
          let a=JSON.parse(this.$route.query.shop)
            let c=JSON.parse(this.$route.query.categories)
            this.shopName=a.title
            this.shopIcon=a.thumb
            this.categoryType=c.type
            this.shopDescription=a.desc
            this.shopTag=a.tag[0].name
            console.log(this.shopName)
          console.log(a)
        },
        methods:{
            submit(){
                const _this = this
                let sform ={
                    shopName: this.shopName,
                    shopPrice: this.shopPrice,
                    shopDescription: this.shopDescription,
                    shopIcon: this.shopIcon,
                    shopTag: this.shopTag,
                    shopStock: this.shopStock,
                    categoryType: this.categoryType
                }
                console.log(sform)
                axios.post('http://localhost:8181/shop/save',sform).then(function (resp) {
                    console.log(resp)
                    if (resp.data===1){
                            _this.$router.push('/specsedit?shopName='+_this.shopName)
                    }
                })
            }
        }
    }
</script>

<style scoped>

</style>