<template>
    <div>
        <h3>商品上架</h3>
        <van-tabbar v-model="active">
            <van-tabbar-item badge="3">
                <span>自定义</span>
                <template #icon="props">
                    <img :src="props.active ? icon.active : icon.inactive" />
                </template>
            </van-tabbar-item>
            <van-tabbar-item icon="home-o"@click="shop">商品管理</van-tabbar-item>
            <van-tabbar-item icon="plus"@click="add">商品上架</van-tabbar-item>
            <van-tabbar-item icon="search" @click="orderM">订单管理</van-tabbar-item>
            <!--<van-tabbar-item icon="https://b.yzcdn.cn/vant/icon-demo-1126.png" @click="wode">我的</van-tabbar-item>-->
        </van-tabbar>

        <div class="box">
            <div class="block" style="margin-bottom: 70px">
                <div class="shop">
                    <div class="row" v-for="(item,i) in goodsList" :key="i">

                        <div class="detail">
                            <div class="photo">
                                <img :src="item.shopIcon" class="img1" alt />
                            </div>
                            <div class="info">
                                <div class="title">商品名：{{item.shopName}}</div>
                                <!--<div class="norm">规格名：{{item.specsName}}</div>-->
                                <div class="norm">描述：{{item.shopDescription}}</div>
                                <div class="norm">数量：{{item.shopStock}}</div>
                                <div class="rol">
                                    <span class="amount">价格：￥{{item.shopPrice}}</span>
                                    <!--<div class="del" >-->
                                  审核中
                                    <!--</div>-->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <van-button class="a" type="primary" @click="addshop">上架商品</van-button>
    </div>


</template>

<script>
    import {
        Toast,
        PullRefresh,
        Swipe,
        SwipeItem
    } from 'vant';
    export default {
        comments:{
            [PullRefresh.name]: PullRefresh,
            [Swipe.name]: Swipe,
            [SwipeItem.name]: SwipeItem
        },
        data() {
            return {
                goodsList: {
                    shopId: '',
                    shopIcon: '',
                    shopName: '',
                    shopDescription:'',
                    specsName: '',
                    specsPrice: '',
                    shopStock: '',
                } ,
            };
        },
        created(){
            if (localStorage.getItem('sid')===null){
                let instance = Toast('请先登录');
                this.$router.push('/loginseller')
            }
            const _this = this
            axios.get('http://localhost:8181/login/findShopByShopStatus/0').then(function (resp) {
                console.log(resp)
                _this.goodsList = resp.data

            })
        },
        methods:{
            fa(i){
                console.log(i)
                const _this = this
                console.log(i)
                axios.get('http://localhost:8181/login/updateShopStatusByShopId/'+this.goodsList[i].shopId).then(function (resp) {
                    console.log(resp)
                    if(resp.data ===1){
                        let instance = Toast('通过审核');
                        setTimeout(() => {
                            instance.close();
                            _this.$router.go(0)
                        }, 1000)
                    }

                })
            },
            shop(){
                this.$router.push('/seller')
            },
            orderM(){
                this.$router.push('/orderm')
            },
            add(){
                this.$router.push('/add')

            },
            addshop(){
                this.$router.push('/addshop')
            }
        }

    }

</script>
<style lang="less" scoped>
    .a{
        position: fixed;
        right: 38%;
        bottom: 50px;
        z-index: 1;
    }
    .box {
        /*position: relative;*/
        /*width: 100%;*/
        /*height: 100%;*/
        /*padding: 30px;*/
        /*box-sizing: border-box;*/
        /*background: #fff;*/
        /*margin-bottom: 104px;*/
    }

    .shop {
        margin-bottom: 6px;
        box-shadow: 0px 8px 20px 0px rgba(97, 97, 97, 0.19);
        border-radius: 12px;
        padding: 10px;
        width: 390px;
        box-sizing: border-box;
    }

    .line {
        display: flex;
        align-items: center;
    }

    .pic {
        width: 40px;
        height: 40px;
    }

    img {
        width: 30px;
        height: 30px;
        object-fit: cover;
    }
    .img1{
        width: 88px;
        height: 88px;
    }
    .line div:nth-child(2) {
        font-size: 24px;
        margin-left: 16px;
    }

    .row {
        display: flex;
        align-items: center;
        margin-top: 10px;
        width: 375.2px;
        height: 128px;
    }

    .detail {
        width: 376px;
        height: 128px;

        margin-left: 0px;
        padding: 20px;
        box-sizing: border-box;
        display: flex;
        align-items: center;
        justify-content: space-between;
    }

    .photo {
        width: 132px;
        height: 132px;
    }

    .info {
        width: 74%;
        height: 100%;
        display: flex;
        justify-content: space-around;
        flex-direction: column;
        text-align: left;
    }

    .title {
        font-size: 15px;
    }

    .norm {
        font-size: 8px;
        color: #999999;
    }

    .rol {
        display: flex;
        align-items: center;
        justify-content: space-between;
    }

    .amount {
        font-size: 15px;
        font-weight: 100;
        color: #ff3b30;
    }

    .del {
        width: 70px;
        display: flex;
        align-items: center;
    }

    .close {
        position: fixed;
        bottom: 49px;
        left: 0;
        width: 389px;
        height: 50px;
        border-top: 1px solid #eeeeee;
        background: #fff;
        display: flex;
        align-items: center;
        justify-content: space-between;
    }

    .all {
        display: flex;
        align-items: center;
        margin-left: 8px;
    }

    .all span {
        color: #999999;
        font-size: 2px;
        margin-left: 5px;
    }

    .refer {
        display: flex;
        align-items: center;
        height: 100%;
    }

    .total {
        display: flex;
        align-items: center;
    }

    .total span:nth-child(1) {
        font-size: 2px;
    }

    .total span:nth-child(2) {
        font-size: 8px;
        font-weight: 600;
        color: #ff3b30;
    }

    .settlement {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 160px;
        height: 50px;
        background: #ff3b30;
        color: #fff;
        font-size: 3px;
        margin-left: 15px;
    }

</style>