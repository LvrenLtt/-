<template>
    <div>
        <h2>审核</h2>
        <div class="box">
            <div class="block" style="margin-bottom: 70px">
                <div class="shop">
                    <div class="row" v-for="(item,i) in goodsList" :key="i">

                        <div class="detail">
                            <div class="photo">
                                <img :src="item.shopIcon" class="img1" alt />
                            </div>
                            <div class="info">
                                <div class="title">商品名：{{item.shopName}}</div>
                                <!--<div class="norm">规格名：{{item.specsName}}</div>-->
                                <div class="norm">描述：{{item.shopDescription}}</div>
                                <div class="norm">数量：{{item.shopStock}}</div>
                                <div class="rol">
                                    <span class="amount">价格：￥{{item.shopPrice}}</span>
                                    <!--<div class="del" >-->
                                    <van-button round type="info" @click="fa(i)">√</van-button>
                                        <van-button round type="info">×</van-button>
                                    <!--</div>-->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


</template>

<script>
    import {
        Toast,
        PullRefresh,
        Swipe,
        SwipeItem
    } from 'vant';
    export default {
        comments:{
            [PullRefresh.name]: PullRefresh,
            [Swipe.name]: Swipe,
            [SwipeItem.name]: SwipeItem
        },
        data() {
            return {
                goodsList: {
                    shopId: '',
                    shopIcon: '',
                    shopName: '',
                    shopDescription:'',
                    specsName: '',
                    specsPrice: '',
                    shopStock: '',
                } ,
            };
        },
        created(){
            if (localStorage.getItem('aid')===null){
                let instance = Toast('请先登录');
                this.$router.push('/admirlogin')
            }
            const _this = this
            axios.get('http://localhost:8181/login/findShopByShopStatus/0').then(function (resp) {
                console.log(resp)
                _this.goodsList = resp.data

            })
        },
        methods:{
            fa(i){
                console.log(i)
                const _this = this
                console.log(i)
                axios.get('http://localhost:8181/login/updateShopStatusByShopId/'+this.goodsList[i].shopId).then(function (resp) {
                    console.log(resp)
                    if(resp.data ===1){
                        let instance = Toast('通过审核');
                        setTimeout(() => {
                            instance.close();
                            _this.$router.go(0)
                        }, 1000)
                    }

                })
            }
        }

    }

</script>
<style lang="less" scoped>
    .box {
        /*position: relative;*/
        /*width: 100%;*/
        /*height: 100%;*/
        /*padding: 30px;*/
        /*box-sizing: border-box;*/
        /*background: #fff;*/
        /*margin-bottom: 104px;*/
    }

    .shop {
        margin-bottom: 6px;
        box-shadow: 0px 8px 20px 0px rgba(97, 97, 97, 0.19);
        border-radius: 12px;
        padding: 10px;
        width: 390px;
        box-sizing: border-box;
    }

    .line {
        display: flex;
        align-items: center;
    }

    .pic {
        width: 40px;
        height: 40px;
    }

    img {
        width: 30px;
        height: 30px;
        object-fit: cover;
    }
    .img1{
        width: 88px;
        height: 88px;
    }
    .line div:nth-child(2) {
        font-size: 24px;
        margin-left: 16px;
    }

    .row {
        display: flex;
        align-items: center;
        margin-top: 10px;
        width: 375.2px;
        height: 128px;
    }

    .detail {
        width: 376px;
        height: 128px;

        margin-left: 0px;
        padding: 20px;
        box-sizing: border-box;
        display: flex;
        align-items: center;
        justify-content: space-between;
    }

    .photo {
        width: 132px;
        height: 132px;
    }

    .info {
        width: 74%;
        height: 100%;
        display: flex;
        justify-content: space-around;
        flex-direction: column;
        text-align: left;
    }

    .title {
        font-size: 15px;
    }

    .norm {
        font-size: 8px;
        color: #999999;
    }

    .rol {
        display: flex;
        align-items: center;
        justify-content: space-between;
    }

    .amount {
        font-size: 15px;
        font-weight: 100;
        color: #ff3b30;
    }

    .del {
        width: 70px;
        display: flex;
        align-items: center;
    }

    .close {
        position: fixed;
        bottom: 49px;
        left: 0;
        width: 389px;
        height: 50px;
        border-top: 1px solid #eeeeee;
        background: #fff;
        display: flex;
        align-items: center;
        justify-content: space-between;
    }

    .all {
        display: flex;
        align-items: center;
        margin-left: 8px;
    }

    .all span {
        color: #999999;
        font-size: 2px;
        margin-left: 5px;
    }

    .refer {
        display: flex;
        align-items: center;
        height: 100%;
    }

    .total {
        display: flex;
        align-items: center;
    }

    .total span:nth-child(1) {
        font-size: 2px;
    }

    .total span:nth-child(2) {
        font-size: 8px;
        font-weight: 600;
        color: #ff3b30;
    }

    .settlement {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 160px;
        height: 50px;
        background: #ff3b30;
        color: #fff;
        font-size: 3px;
        margin-left: 15px;
    }

</style>