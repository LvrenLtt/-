<template>
  <div>
    <div id="ad" v-if="adisshow" >
      <img src="../../public/static/shouye.jpg" alt="">
      <span class="headtitle">婚  庆</span>
      <span class="headtitle1">终于等到你，还好没放弃。</span>
      <div class="circle "  @click="goHome">
        <van-circle v-model="currentRate" :rate="100" :speed="20" size="50" :color="gradientColor"
        ><span class="timer">{{m}}</span></van-circle>
        </div>
    </div>
    <div class="version"><span>V </span><span> 1.0</span></div>
  </div>
</template>
<script>

export default {
  data () {
    return {
      m:5,
      timer:null,
      adisshow:true,
      currentRate:0,
      gradientColor: {
        '0%': '#3fecff',
        '100%': '#6149f6',
      },
    }
  },
  created () {
    this.autoplay()
  },
  methods: {
    autoplay(){
      this.timer = setInterval(() => {
        this.play()
      }, 1000)
    },
    play(){
      this.m--
      if (this.m==0) {
        this.goHome()
      }
    },
    goHome(){
      this.adisshow=false
      this.$router.push('/select')
      clearInterval(this.timer)
    }
  },
  destroyed () {
    clearInterval(this.timer)
  } 
}
</script>
<style >
#ad{
  width: 23.4375rem;
  height: 41.6875rem;
  position: relative;
}
#ad img{
  width: 100%;
  height: 100%;
}
.timer{
  color: white;
  position: absolute;
  top: 1.125rem;
  right: 1.375rem;
  text-align: center;
}
.circle{
  position: absolute;
  top: 0.9375rem;
  right: 0.875rem;
}
.headtitle{
  width: 9.375rem;
  height: 1.875rem;
  position: absolute;
  left: 30%;
  top: 17%;
  font-size: 1.875rem;
  font-family: Regular,Droid Sans,Droid Sans Fallback,STHeiti,SimHei,Hei;
  color: rgb(0, 255, 255);
}
.headtitle1{
  position: absolute;
  left: 27%;
  top: 24%;
  font-size: 1rem;
  font-family: Regular,Droid Sans,Droid Sans Fallback,STHeiti,SimHei,Hei;
  color:rgba(12, 165, 170, 0.664);

}
.version{
  width: 5rem;
  height: 1.5625rem;
  position: absolute;
  bottom: 1.25rem;
  right: 35%;
  color: white;
  font-size: 1.125rem;
  font-family: Regular,Droid Sans,Droid Sans Fallback,STHeiti,SimHei,Hei;
  color: rgb(0, 255, 255);
}
</style>

