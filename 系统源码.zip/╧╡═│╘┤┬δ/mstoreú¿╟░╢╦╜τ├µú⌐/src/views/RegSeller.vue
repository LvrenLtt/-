<template>
    <div>
        <van-form @submit="onSubmit">
            <van-field
                    v-model="username"
                    name="用户名"
                    label="用户名"
                    placeholder="用户名"
                    :rules="[{ required: true, message: '请填写用户名' }]"
            />
            <van-field
                    v-model="password"
                    type="password"
                    name="密码"
                    label="密码"
                    placeholder="密码"
                    :error-message="pass"
                    :rules="[{ required: true, message: '请填写密码' }]"
            />
            <!--<van-field-->
                    <!--v-model="phonenumber"-->
                    <!--name="手机号"-->
                    <!--label="手机号"-->
                    <!--placeholder="手机号"-->
                    <!--:error-message="usertel"-->
                    <!--:rules="[{ required: true, message: '请填写手机号' }]"-->
                    <!--clearable-->

            <!--/>-->

            <div style="margin: 16px;">
                <van-button round block type="info" native-type="submit">提交</van-button>
            </div>
        </van-form>
    </div>
</template>

<script>
    import {Toast} from "vant"
    export default {
        data() {
            return {
                username: '',
                password: '',
                phonenumber:'',
                email:''
            };
        },
        methods: {
            onSubmit() {
                const _this = this
                let rform={
                    sellerName: this.username,
                    sellerPass: this.password,
                    // phonenumber: this.phonenumber,
                   /* email: ''*/
                }
                console.log('submit', rform);
                axios.post('http://localhost:8181/login/regseller',rform).then(function (resp) {

                    console.log(resp)
                    if(resp.data ===1){
                        Toast.success({
                            message:"用户名已存在，请去登录",
                            duration:1000
                        })

                        setTimeout(() => {
                            _this.$router.push('/login')
                        }, 1000)

                    }
                    else
                    {
                        Toast.success({
                            message:"注册成功，请去登录",
                            duration:1000
                        })

                        setTimeout(() => {
                            _this.$router.push('/login')
                        }, 1000)
                    }

                })
            },
        },
        computed: {
            usertel () {
                if (this.phonenumber === ""){
                    return ''
                }else if(!/^[1][3,4,5,7,8][0-9]{9}$/.test(this.phonenumber)){
                    return '手机号格式错误'
                }else {
                    return ''
                }
            },
            pass () {
                if (this.password === ""){
                    return ''
                }else if(this.password.length<6){
                    return '密码不可小于6位'
                }else {
                    return ''
                }
            },
        }
    };
</script>

<style scoped>

</style>