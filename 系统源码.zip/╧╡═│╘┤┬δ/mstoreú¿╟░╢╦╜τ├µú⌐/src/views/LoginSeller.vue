<template>
    <div class="loginpage" >
        <img src="../../public/static/denglu.png" class="a">
        <van-form @submit="onSubmit" class="st" >
            <van-field
                    v-model="username"
                    name="用户名"
                    label="用户名"
                    placeholder="用户名"
                    :rules="[{ required: true, message: '请填写用户名' }]"
                    clearable
            />
            <van-field
                    v-model="password"
                    type="password"
                    name="密码"
                    label="密码"
                    placeholder="密码"
                    :rules="[{ required: true, message: '请填写密码' }]"
                    clearable
            />
            <div style="margin: 16px;">
                <van-button round type="info" native-type="submit">登录</van-button>
                <van-button round type="info" native-type="register" @click="register">注册</van-button>
            </div>
        </van-form>
    </div>
</template>

<script>
    import {Toast} from "vant"
    export default {
        data() {
            return {
                username: '',
                password: '',
            };
        },
        methods: {
            onSubmit(values) {
                console.log('submit', values);
                let lform={
                    sellerName: this.username,
                    sellerPass: this.password,
                }
                console.log(lform);

                const _this = this
                axios.post('http://localhost:8181/login/loginingS',lform).then(function (resp) {
                    // _this.username=resp.data
                    //获取username
                    localStorage.setItem('sid',resp.data)
                    console.log(resp)
                    console.log(localStorage.getItem('sid'))

                    if(resp.data ===0){
                        Toast.success({
                            message:"用户名或密码错误",
                            duration:1000
                        })
                    }else {
                        Toast.success({
                            message:"登录成功",
                            duration:1000
                        })
                        setTimeout(() => {
                            _this.$router.push('/seller')
                        }, 1000)
                    }
                })

            },
            register(){
                this.$router.push('/regseller')
            }
        },
    };
</script>

<style scoped>
    .loginpage{
        position: relative;
    }
    .st{
        /*margin: 50% auto;*/
        width: 375px;
        background-color: #fefff9;
        position: absolute;
        top: 200px ;
    }
    .a{
        width: 375px;
        height: 667px;
    }
</style>