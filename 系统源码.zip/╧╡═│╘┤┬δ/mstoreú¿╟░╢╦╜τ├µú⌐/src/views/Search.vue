<template>
    <div>
        <form action="/" >
            <van-search
                    v-model="value"
                    show-action
                    placeholder="请输入搜索关键词"
                    shape="round"
                    background="#ee0a24"
                    @search="onSearch"
                    @cancel="onCancel"
            />
        </form>

        <van-row>
            <van-col span="24">
              <van-card v-for="(item,index) in shops"
                                  :price="item.price"
                                  :desc="item.desc"
                                  :title="item.title"
                                  :thumb="item.thumb"
                                  :key="index"
                        >
                            <template #tags>
                                <van-tag v-for="tag in item.tag" color="#f2826a" style="margin-left: 5px;" :key="index">{{tag.name}}</van-tag>
                            </template>
                            <template #footer>
                                <van-button round type="info" size="mini" @click="buy(index)">购买</van-button>
                            </template>
                        </van-card>
            </van-col>
        </van-row>

        <van-sku
                v-model="show"
                :sku="sku"
                :goods="goods"
                :hide-stock="sku.hide_stock"
                @buy-clicked="onBuyClicked"
        >
            <template #sku-actions="props">
                <div class="van-sku-actions">
                    <van-button
                            square
                            size="large"
                            type="danger"
                            @click="props.skuEventBus.$emit('sku:buy')"
                    >
                        购买
                    </van-button>
                </div>
            </template>
        </van-sku>
    </div>
</template>

<script>
    import {
        Toast,
        PullRefresh,
        Swipe,
        SwipeItem
    } from 'vant';
    export default {
        comments:{
            [PullRefresh.name]: PullRefresh,
            [Swipe.name]: Swipe,
            [SwipeItem.name]: SwipeItem
        },
        data() {
            return {
                images: [
                    '../static/e84a2e03-7f19-41d2-98a5-a5c16b7e252d.jpg',
                    '../static/e84a2e03-7f19-41d2-98a5-a5c16b7e252d.jpg',
                    '../static/e84a2e03-7f19-41d2-98a5-a5c16b7e252d.jpg',
                    '../static/e84a2e03-7f19-41d2-98a5-a5c16b7e252d.jpg',
                ],
                categories: '',
                shops: '',
                show: true,
                sku: '',
                goods: '',
                value: ''
            }
        },
        methods: {
            buy(index){
                if (localStorage.getItem('id')===null){
                    let instance = Toast('无法购买，请先登录');
                    this.$router.push('/login')
                }
                this.show = true
                const _this = this
                axios.get('http://localhost:8181/shop/findSpecsByShopId/'+this.shops[index].id).then(function (resp) {
                    _this.goods = resp.data.data.goods
                    _this.sku = resp.data.data.sku
                })
            },
            onBuyClicked(item){
                this.$store.state.specsId = item.selectedSkuComb.s1
                this.$store.state.quantity = item.selectedNum
                this.$router.push('/addressList')
            },
            shouye(){
                this.$router.push('/shouye')
            },
            wode(){
                this.$router.push('/my')
            },
            fenlei(){
                this.$router.push('/home')
            },
            onSearch(value) {
                console.log(value)
                const _this = this
                axios.get('http://localhost:8181/shop/findByShopName/'+value).then(function (resp) {
                    console.log(resp)
                    _this.shops = resp.data.data
                })
            },
            onCancel() {
                this.$router.push('/shouye')
            },
        },

    }
</script>
<style scoped>
    .my-swipe .van-swipe-item {
        color: #f2f3f5;
        font-size: 20px;
        line-height: 150px;
        text-align: center;
        background-color: #EE3E3B;
    }
</style>