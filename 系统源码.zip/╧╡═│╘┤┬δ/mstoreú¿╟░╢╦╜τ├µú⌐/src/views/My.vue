<template>
    <div>
        <h3>个人中心</h3>
        <van-grid>
            <!--<van-grid-item icon="photo-o" text="钱包" />-->
            <van-grid-item icon="location-o"text="地址管理" to='/addressList'/>
            <!--<van-grid-item icon="photo-o" text="文字" />-->
        </van-grid>
        <h2>我的订单</h2>
        <van-grid>
            <van-grid-item icon="pending-payment" text="待付款" to="/daifukuan"/>
            <van-grid-item icon="send-gift-o" text="待发货" to="/daifahuo"/>
            <van-grid-item icon="logistics" text="待收货" to="daishouhuo"/>
            <van-grid-item icon="certificate" text="已完成" to="yiwancheng"/>

        </van-grid>
        <van-button class="a" round type="info" size="large" @click="out">退出</van-button>
        <van-tabbar v-model="active">
            <van-tabbar-item badge="3">
                <span>自定义</span>
                <template #icon="props">
                    <img :src="props.active ? icon.active : icon.inactive" />
                </template>
            </van-tabbar-item>
            <van-tabbar-item icon="home-o"@click="shouye">首页</van-tabbar-item>
            <van-tabbar-item icon="cart-o" @click="fenlei">购物车</van-tabbar-item>
            <van-tabbar-item icon="https://b.yzcdn.cn/vant/icon-demo-1126.png" @click="wode">我的</van-tabbar-item>
        </van-tabbar>
    </div>
</template>

<script>
    export default {
        methods:{
            denglu(){
                this.$router.push('/login')
            },
            shouye(){
                this.$router.push('/shouye')
            },
            wode(){
                this.$router.push('/my')
            },
            fenlei(){
                this.$router.push('/home')
            },
            address(){
                this.$router.push('/addressList')

            },
            out(){
                localStorage.removeItem('id')
                this.$router.push('/login')
            }
        }
    }
</script>

<style scoped>
.de{
    margin: 80% auto;
}
.a{
    position: fixed;
    right: 0;
    bottom: 50px;
    z-index: 1;
}
</style>